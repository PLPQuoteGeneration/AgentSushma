package com.cg.qgs.client;

import java.util.InputMismatchException;
import java.util.Scanner;

public class UI {

	public static void main(String[] args) {

		agentMenu();

	}

	private static void agentMenu() {
		int choice = 0;
		boolean choiceFlag = false;
		Scanner scanner = new Scanner(System.in);

		do {
			System.out.println("***********Agent*************");
			System.out.println("1.Account Creation");
			System.out.println("2.Policy Creation");
			System.out.println("3.View Policy");
			System.out.println("4.Exit");

			System.out.println("Enter your choice");
			scanner = new Scanner(System.in);
			try {
				choice = scanner.nextInt();
				choiceFlag = false;

			} catch (InputMismatchException e) {
				choiceFlag = false;
				e.printStackTrace();
			}
		} while (!choiceFlag);
		switch (choice) {
		case 1:
			// accounts = getAccountCreation();

			break;
		case 2:
			// getPolicyCreation();
			break;

		case 3:
			// getViewPolicy();
			break;
		case 4:
			System.exit(0);
			break;

		default:
			break;
		}

	}

}
