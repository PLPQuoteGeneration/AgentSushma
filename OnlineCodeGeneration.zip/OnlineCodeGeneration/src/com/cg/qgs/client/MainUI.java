package com.cg.qgs.client;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;



import com.cg.qgs.exception.QGSException;
import com.cg.qgs.model.Accounts;
import com.cg.qgs.model.BusinessSegment;
import com.cg.qgs.model.Policy;
import com.cg.qgs.model.PolicyDetails;
import com.cg.qgs.model.PolicyQuestions;
import com.cg.qgs.service.QGSService;
import com.cg.qgs.service.QGSServiceImpl;

public class MainUI {
	static QGSService service = null;
	static Scanner scanner = null;
	static Accounts accounts = null;
	static PolicyQuestions policy = null;

	public static void main(String[] args) {

		int choice;
		boolean flag = false;

		do {
			try {

				scanner = new Scanner(System.in);
				System.out.println("***********Agent*************");
				System.out.println("1.Account Creation");
				System.out.println("2.Policy Creation");
				System.out.println("3.View Policy");
				System.out.println("4.Exit");

				System.out.println("Enter your choice");

				choice = scanner.nextInt();

				switch (choice) {
				case 1:
					System.out.println("\n==== Account Creation Screen ====");

					boolean validateflag = false;
					do {
						scanner.nextLine();
						accounts = getAccountCreation();

						service = new QGSServiceImpl();
						try {
							validateflag = service.getValidations(accounts);
							if (validateflag) {
								long insertRecords = service
										.getInsertion(accounts);
								flag = true;
								System.out.println("Your Account Number is..."
										+ insertRecords);
							}

						} catch (QGSException e) {
							flag = false;
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (InputMismatchException e) {
							flag = false;
							System.out.println(e.getMessage());
						}
					} while (!validateflag);

					break;
				case 2:
					System.out.println("\n==== Policy Creation Screen ====");
					service = new QGSServiceImpl();
					getPolicyCreation();
					flag = true;
					break;
				case 3:
					System.out.println("\n======View Policy=======");
					service=new QGSServiceImpl();
					try {
						getViewPolicy();
						flag = true;
					} catch (QGSException e) {
						// TODO Auto-generated catch block
						flag = false;
						e.printStackTrace();
					}
					break;
				case 4: 
					System.exit(0);
					return;
				default:
					System.err.println("Enter a Valid option");
				}
			} catch (InputMismatchException e) {
				System.err.println("Enter number format");
			}

			
			
		} while (!flag);

	}

	private static void getViewPolicy() throws QGSException {
		List<Policy> list3 = new ArrayList<Policy>();
		list3=service.getViewPolicy();
		
		if (list3.size() > 0) {
			System.out
					.println("PolicyNumber       PolicyPremium       AccountNumber       BusinessSegment");
			for (Policy policy : list3) {
				System.out.println(policy.getPolicyNumber()
						+ "       "
						+ policy.getPolicyPremium()
						+ "       " + policy.getAccountNumber()
						+ "       "
						+ policy.getBuisnessSegement());
			}
		}
		else {
			System.out.println("Policy Records are not found:");
			
		}
		
	}

	private static PolicyQuestions getPolicyCreation() {

		double policyPremium = 0.0;
		boolean accountFlag = false;
		/*String polQuesId = null;*/
		BusinessSegment businessSegment2 = new BusinessSegment();
		PolicyQuestions questions = new PolicyQuestions();
		do{
		System.out.println("Enter Account No: ");
		Long accountNumber = scanner.nextLong();
		
		try {
			boolean result = service.checkingAccount(accountNumber);
			if (result) {
				accountFlag = true;
				List<BusinessSegment> list = new ArrayList<BusinessSegment>();
				List<PolicyQuestions> list2 = new ArrayList<PolicyQuestions>();
				QGSService service = new QGSServiceImpl();

				try {
					list = service.viewBusinessSegment();
					if (list.size() > 0) {
						System.out.println("\nBusiness Segment Name:\n");
						int choice = 1;
						for (BusinessSegment businessSegment : list) {
							System.out.println(choice++ + ". "
									+ businessSegment.getBusSegName());

							businessSegment2.setBusSegId(businessSegment
									.getBusSegId());
							businessSegment2.setBusSegName(businessSegment
									.getBusSegName());

						}
						System.out.println("please select policy");
						int choices = scanner.nextInt();
						String business = null;
						switch (choices) {
						case 1:
							business = "Business Auto";
							break;

						case 2:
							business = "Restaurant";
							break;

						case 3:
							business = "Apartment";
							break;

						case 4:
							business = "General Merchant";
							break;

						default:
							break;
						}
						list2 = service.viewPolicyDetails(business);

						int i = 1;
						List<PolicyDetails> questions2 = new ArrayList<PolicyDetails>();
						for (PolicyQuestions policyQuestions : list2) {

							System.out.println("Question " + i + ": "
									+ policyQuestions.getQuestion() + "\n 1: "
									+ policyQuestions.getPolQuesAns1()
									+ "\n 2: "
									+ policyQuestions.getPolQuesAns2()
									+ "\n 3: "
									+ policyQuestions.getPolQuesAns3()
									+ "\n Enter your option :\n");
							i++;
							
							/*String questionAnswer;*/
							PolicyDetails details=new PolicyDetails();
							details.setPolQuesId(policyQuestions
									.getPolQuesId());
							int choice1 = scanner.nextInt();
							switch (choice1) {
							case 1:
								policyPremium += policyQuestions
										.getPolQuesAns1Weightage();
								details.setPolQuesAns(policyQuestions.getPolQuesAns1());
								

								break;

							case 2:
								policyPremium += policyQuestions
										.getPolQuesAns2Weightage();
								details.setPolQuesAns(policyQuestions.getPolQuesAns2());
								
								break;

							case 3:
								policyPremium += policyQuestions
										.getPolQuesAns3Weightage();
								details.setPolQuesAns(policyQuestions.getPolQuesAns3());
								
								break;

							default:
								break;
							}
							System.out.println("Your premium is...."
									+ policyPremium);
							questions2.add(details);

						}

						questions.setPolicyPremium(policyPremium);
						questions.setAccountNumber(accountNumber);
						questions.setBuisnessSegement(business);
						list2 = service.insertPolicy(questions);
						
						service.insertIntoPolicyDetails(questions2);
						System.out.println("Inserted\n	");

					} else {
						System.out.println("No records found");
					}

				} catch (QGSException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} else {
				System.err.println("Account number doesn't exists");
			}
		} catch (QGSException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		}while(!accountFlag);
		return questions;

	}

	private static Accounts getAccountCreation() {

		Accounts accounts = new Accounts();
		System.out.println("Enter Insured Name : ");
		String insuredName = scanner.nextLine();
		System.out.println("Enter Insured Street : ");
		String insuredStreet = scanner.nextLine();
		System.out.println("Enter Insured City : ");
		String insuredCity = scanner.nextLine();
		System.out.println("Enter Insured State :");
		String insuredState = scanner.nextLine();
		Long insuredZip = null;
		try {
			System.out.println("Enter Insured Zip");
			insuredZip = scanner.nextLong();
			accounts.setInsuredZip(insuredZip);
		} catch (InputMismatchException e) {
			accounts.setInsuredZip(1l);

		}

		accounts.setInsuredName(insuredName);
		accounts.setInsuredStreet(insuredStreet);
		accounts.setInsuredCity(insuredCity);
		accounts.setInsuredState(insuredState);

		return accounts;
	}

}
