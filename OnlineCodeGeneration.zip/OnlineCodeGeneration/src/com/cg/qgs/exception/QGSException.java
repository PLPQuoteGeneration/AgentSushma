package com.cg.qgs.exception;
@SuppressWarnings("serial")
public class QGSException extends Exception {

	public QGSException(String message) {
		super(message);
	}
}