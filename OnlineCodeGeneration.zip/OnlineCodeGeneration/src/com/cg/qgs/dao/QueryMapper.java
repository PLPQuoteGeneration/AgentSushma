package com.cg.qgs.dao;

public interface QueryMapper {

	public static final String getinsertrecord = "INSERT INTO accounts VALUES(account_number_seq.nextval,?,?,?,?,?,?)";
	public static final String viewAccountNo = "SELECT account_number_seq.currval FROM dual ";
	public static final String viewBusinessSegment = "SELECT BUS_SEG_NAME FROM businessSegment";
	public static final String displayAccountNo = "SELECT ACCOUNT_NUMBER from accounts";
	public static final String viewPolicyDetails = "SELECT * from policyquestions where bus_seg_id = (select bus_seg_id from businesssegment where bus_seg_name = ?)";
	public static final String getinsertPolicy = "INSERT INTO policy VALUES(policy_seq.nextval,?,?,?)";
	public static final String displayPolicyNo = "SELECT policy_seq.currval from dual";
	public static final String insertIntoPolicyDetails = "insert into policyDetails values(?,?,?)";
	public static final String selectPolicy = "select p.policy_number,p.policy_premium,p.account_number,p.business_segment from policy p,accounts a,userrole u where u.username=a.username and a.account_number=p.account_number and u.username=?";

}
