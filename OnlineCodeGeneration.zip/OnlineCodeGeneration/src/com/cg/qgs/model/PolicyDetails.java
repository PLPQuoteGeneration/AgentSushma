package com.cg.qgs.model;

public class PolicyDetails {
	private Long policyNumber;
	private String polQuesId;
	private String polQuesAns;
	public PolicyDetails() {
		// TODO Auto-generated constructor stub
	}
	public PolicyDetails(Long policyNumber, String polQuesId, String polQuesAns) {
		super();
		this.policyNumber = policyNumber;
		this.polQuesId = polQuesId;
		this.polQuesAns = polQuesAns;
	}
	public Long getPolicyNumber() {
		return policyNumber;
	}
	public void setPolicyNumber(Long policyNumber) {
		this.policyNumber = policyNumber;
	}
	public String getPolQuesId() {
		return polQuesId;
	}
	public void setPolQuesId(String polQuesId) {
		this.polQuesId = polQuesId;
	}
	public String getPolQuesAns() {
		return polQuesAns;
	}
	public void setPolQuesAns(String polQuesAns) {
		this.polQuesAns = polQuesAns;
	}

}
