package com.cg.qgs.model;

public class Policy {
	private Long policyNumber;
	private Double policyPremium;
	private long accountNumber;
	private String buisnessSegement;
	public Long getPolicyNumber() {
		return policyNumber;
	}
	public void setPolicyNumber(Long policyNumber) {
		this.policyNumber = policyNumber;
	}
	public Double getPolicyPremium() {
		return policyPremium;
	}
	public void setPolicyPremium(Double policyPremium) {
		this.policyPremium = policyPremium;
	}
	public long getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(long accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getBuisnessSegement() {
		return buisnessSegement;
	}
	public void setBuisnessSegement(String buisnessSegement) {
		this.buisnessSegement = buisnessSegement;
	}
	public Policy(Long policyNumber, Double policyPremium, long accountNumber,
			String buisnessSegement) {
		super();
		this.policyNumber = policyNumber;
		this.policyPremium = policyPremium;
		this.accountNumber = accountNumber;
		this.buisnessSegement = buisnessSegement;
	}
	public Policy() {
		super();
	}

	
	
	
}
